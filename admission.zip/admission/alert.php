
        <!-- BEGIN GLOBAL MANDATORY STYLES -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:400,600,700" rel="stylesheet">
    <link href="admin/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="admin/assets/css/plugins.css" rel="stylesheet" type="text/css" />
    <!-- END GLOBAL MANDATORY STYLES -->

    <!-- BEGIN THEME GLOBAL STYLES -->
    <link href="admin/assets/css/scrollspyNav.css" rel="stylesheet" type="text/css" />
    <link href="admin/plugins/animate/animate.css" rel="stylesheet" type="text/css" />
    <script src="admin/plugins/sweetalerts/promise-polyfill.js"></script>
    <link href="admin/plugins/sweetalerts/sweetalert2.min.css" rel="stylesheet" type="text/css" />
    <link href="admin/plugins/sweetalerts/sweetalert.css" rel="stylesheet" type="text/css" />
    <link href="admin/assets/css/components/custom-sweetalert.css" rel="stylesheet" type="text/css" />
    
    
    <!-- BEGIN GLOBAL MANDATORY STYLES -->
    <script src="admin/assets/js/libs/jquery-3.1.1.min.js"></script>
    <script src="admin/bootstrap/js/popper.min.js"></script>
    <script src="admin/bootstrap/js/bootstrap.min.js"></script>
    <script src="admin/plugins/perfect-scrollbar/perfect-scrollbar.min.js"></script>
    <script src="admin/assets/js/app.js"></script>
    
    <script>
        $(document).ready(function() {
            App.init();
        });
    </script>
    <script src="admin/plugins/highlight/highlight.pack.js"></script>
    <script src="admin/assets/js/custom.js"></script>
    <!-- END GLOBAL MANDATORY STYLES -->
    
    <!-- BEGIN THEME GLOBAL STYLE -->
    <script src="admin/assets/js/scrollspyNav.js"></script>
    <script src="admin/plugins/sweetalerts/sweetalert2.min.js"></script>
    <script src="admin/plugins/sweetalerts/custom-sweetalert.js"></script>
    <!-- END THEME GLOBAL STYLE --> 
<?php
$stat=$_GET['error'];
if ($stat=='false') {
   echo "<script>swal({
      title: 'Thank You!',
      text: 'Form submitted successfullyadmin/',
      type: 'success',
      padding: '2em'
    })</script>";  
}elseif ($stat=='del') {
    echo "<script>swal({
           title: 'deleted!',
      text: 'Record has been deleted!',
      type: 'success',
      padding: '2em'
        })</script>";
}
?>

