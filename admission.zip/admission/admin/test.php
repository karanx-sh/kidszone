<?php
echo date("ymd",strtotime('2020-12-02')).'12';
?>