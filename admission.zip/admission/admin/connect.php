<?php
$dbServername= "localhost";
  $dbUsername= strtolower('thekidsz_usr1');
  $dbPassword= "Qsy;[TNPkpVA";
  $dbName= strtolower('thekidsz_form');

// $dbUsername= 'root';
// $dbPassword='' ;
// $dbName= 'form';
$conn = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName) or die("Connection failed{Databas}");
?>