<?php
include_once('connect.php');
session_start();
if ($_SESSION['privilege']== 'admin' || $_SESSION['privilege']== 'assistant') {

}else{
  header("Location:index.php?login=error"); 
  exit(); 
    echo "<script>window.open('index.php?login=error','_self')</script>";
}
$id=$_GET['id'];
 $sql3="UPDATE `user` SET `status`=2 WHERE status=0  AND id=".$id;
 mysqli_query($conn, $sql3) or die(mysqli_error($conn));
 
 header("Location:admin.php?stat=del"); 
  exit(); 
    echo "<script>window.open('admin.php?stat=del','_self')</script>";
?>