<?


$message=urlencode('Parent name: '.$row['fname'].'Parent number: '.$row['f_phone'].'/'.$row['m_phone'].',  has submitted form '.date("Y-m",strtotime($row['date'])).'-'.$row['id'].', have a look');
                       $url='http://text.daxy.in/http-api.php?username=kidszone&password=DU00MUD0BA&senderid=KIDZON&route=2&number='.$row['phone'].'&message='.$message.'';
                       $ch = curl_init();

                        // set URL and other appropriate options
                        curl_setopt($ch, CURLOPT_URL, $url);
                        curl_setopt($ch, CURLOPT_HEADER, 0);

                        // grab URL and pass it to the browser
                        curl_exec($ch);

                        // close cURL resource, and free up system resources
                        curl_close($ch);
                        // echo $url;
                        // header("Location:admin.php?stat=v");
                        // exit();
                        
                        
                        $message=urlencode('Thank you! we have received your form and our team is reviewing it! will contact you asap 🤞🏻😇');
                       $url='http://text.daxy.in/http-api.php?username=kidszone&password=DU00MUD0BA&senderid=KIDZON&route=2&number='.$row['phone'].'&message='.$message.'';
                       $ch = curl_init();

                        // set URL and other appropriate options
                        curl_setopt($ch, CURLOPT_URL, $url);
                        curl_setopt($ch, CURLOPT_HEADER, 0);

                        // grab URL and pass it to the browser
                        curl_exec($ch);

                        // close cURL resource, and free up system resources
                        curl_close($ch);
                    

                        ?>
                        