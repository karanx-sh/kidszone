<?php
ini_set("include_path", '/home/thekidsz/php:' . ini_get("include_path") );
require_once "Mail.php";
include_once('../connect.php');
$email=mysqli_real_escape_string($conn, $_POST['email']);
$sql="SELECT * FROM admin WHERE username='".$email."'"; 
        $result=mysqli_query($conn,$sql);
        $row = mysqli_fetch_assoc($result);
        $check=mysqli_num_rows($result);
        if($check >= 1){


            
            function my_simple_crypt( $string, $action ) {
                // you may change these values to your own
                $secret_key = 'my_simple_secret_key';
                $secret_iv = 'my_simple_secret_iv';
             
                $output = false;
                $encrypt_method = "AES-256-CBC";
                $key = hash( 'sha256', $secret_key );
                $iv = substr( hash( 'sha256', $secret_iv ), 0, 16 );
             
                if( $action == 'e' ) {
                    $output = base64_encode( openssl_encrypt( $string, $encrypt_method, $key, 0, $iv ) );
                }
                else if( $action == 'd' ){
                    $output = openssl_decrypt( base64_decode( $string ), $encrypt_method, $key, 0, $iv );
                }
             
                return $output;
            }
            $email=$row['username'];
            $id=my_simple_crypt($row['username'],'e');
            $ntime=strtotime(date('Y-m-d H:i:s'));
$time=my_simple_crypt($ntime,'e');

            $url="https://thekidszone.in/admission/admin/resetpass.php?id=".$id."&time=".$time;
              
            // $email  = "karan.patil@sakec.ac.in";
            
            $from    = "no-reply@thekidszone.in";
            $subject = "Password reset link"; 
            $message = '
            <head>
            <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">       
            </head>
            <body>
            <div align="center" style="margin: 0px auto;">
            <table style="max-width:600px" width="100%" cellspacing="0" cellpadding="0" border="0">
                <tbody>
                    <tr>
                        <td valign="top" align="center">
                            
                            <table width="100%" cellspacing="0" cellpadding="0" border="0">
                                <tbody>
                                    <tr>
                                        <td style="padding-top:20px;padding-right:0px" valign="middle" align="right">
                                            

                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            
                        </td>
                    </tr>
                </tbody>
            </table>
            

            
            <table style="max-width:600px" width="100%" cellspacing="0" cellpadding="0" border="0">
                <tbody>
                    <tr>
                        <td valign="top" align="center">
                            
                            <table width="100%" cellspacing="0" cellpadding="0" border="0">
                                <tbody>
                                    <tr>
                                        <td style="padding-top:40px;padding-bottom:40px" valign="middle" align="center">
                                            
                                            <a href="#m_-2033841538094845514_" style="text-decoration:none">
                                                <p style="font-family:\'Damion\',cursive;color:black;font-size:60">
                                                    From Team Daxy
                                                </p>

                                            </a>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            
                        </td>
                    </tr>
                </tbody>
            </table>
            

            
            <table style="max-width:600px" width="100%" cellspacing="0" cellpadding="0" border="0">
                <tbody>
                    <tr>
                        <td valign="top" align="center">

                            
                            <table style="background-color:#ffffff;border-color:#e5e5e5;border-style:solid;border-width:0 1px 1px 1px" width="100%" cellspacing="0" cellpadding="0" border="0">

                                <tbody>
                                    <tr>
                                        
                                        <td style="background-color:#003ce5;font-size:1px;line-height:3px" height="3">&nbsp;</td>
                                    </tr>


                                    <tr>
                                        <td style="padding-bottom:20px" valign="top" align="center">
                                            
                                            <a href="#m_-2033841538094845514_" style="text-decoration:none">
                                                <img src="https://ci6.googleusercontent.com/proxy/IZse1hWptzWcxsGr7qJ0Apqp_YxjuXUn53QJZ7xdaM6nd22_4CcWiJ407P3yyZJtqA4DneqQOzEFDpsrnMDpFcH100DSPyVOmptI938QeFwqBCAMwG8RdXiaTgWjtnzRE2Ma1XH_o4CIgf2J=s0-d-e1-ft#http://weekly.grapestheme.com/notify/img/hero-img/blue/heroFill/notification-reminder.png" alt="" style="width:100%;max-width:600px;height:auto;display:block" class="CToWUd" width="600" border="0">
                                            </a>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td style="padding-bottom:5px;padding-left:20px;padding-right:20px" valign="top" align="center">
                                            
                                            <h2 style="color:#000000;font-family:\'Poppins\',Helvetica,Arial,sans-serif;font-size:28px;font-weight:500;font-style:normal;letter-spacing:normal;line-height:36px;text-transform:none;text-align:center;padding:0;margin:0">
                                                Notification!
                                            </h2>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td style="padding-bottom:30px;padding-left:20px;padding-right:20px" valign="top" align="center">
                                            
                                            <h4 style="color:#999999;font-family:\'Poppins\',Helvetica,Arial,sans-serif;font-size:16px;font-weight:500;font-style:normal;letter-spacing:normal;line-height:24px;text-transform:none;text-align:center;padding:0;margin:0">
                                                You have a new update</h4>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td style="padding-left:20px;padding-right:20px" valign="top" align="center">

                                            <table width="100%" cellspacing="0" cellpadding="0" border="0">
                                                <tbody>
                                                    <tr>
                                                        <td style="padding-top:20px;padding-bottom:40px" valign="top" align="center">
                                                            
                                                            <table width="100%" cellspacing="0" cellpadding="0" border="0">
                                                                <tbody>
                                                                    <tr>
                                                                        <td style="background-color:#e5e5e5;font-size:1px;line-height:1px" height="1">&nbsp;</td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>

                                            <table width="100%" cellspacing="0" cellpadding="0" border="0">
                                                <tbody>
                                                    <tr>
                                                        <td style="padding-bottom:10px" valign="top" align="center">
                                                            
                                                            <p style="color:#777777;font-family:\'Poppins\',Helvetica,Arial,sans-serif;font-size:16px;font-weight:500;font-style:normal;letter-spacing:normal;line-height:22px;text-transform:none;text-align:center;padding:0;margin:0">
                                                                Details</p>
                                                        </td>
                                                    </tr>

                                                    <tr>
                                                        <td style="padding-bottom:20px" valign="top" align="center">
                                                            
                                                        <a href="'.$url.'" target="_blank">Password Resset link</a>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>





                                            <table width="100%" cellspacing="0" cellpadding="0" border="0">
                                                <tbody>
                                                    <tr>
                                                        <td style="padding-top:20px;padding-bottom:40px" valign="top" align="center">
                                                            
                                                            <table width="100%" cellspacing="0" cellpadding="0" border="0">
                                                                <tbody>
                                                                    <tr>
                                                                        <td style="background-color:#e5e5e5;font-size:1px;line-height:1px" height="1">&nbsp;</td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>

                                            <table width="100%" cellspacing="0" cellpadding="0" border="0">
                                                <tbody>
                                                    <tr>
                                                        <td style="padding-bottom:20px" valign="top" align="center">
                                                            
                                                            <p style="width:390px;color:#666666;font-family:\'Open Sans\',Helvetica,Arial,sans-serif;font-size:14px;font-weight:400;font-style:normal;letter-spacing:normal;line-height:22px;text-transform:none;text-align:center;padding:0;margin:0">
                                                                This is a system generated mail! make sure you
                                                                are keeping the system up to date! and
                                                                maintaining it correctly
                                                            </p>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>



                                        </td>
                                    </tr>




                                </tbody>
                            </table>
                            

                            
                            <table width="100%" cellspacing="0" cellpadding="0" border="0">
                                <tbody>
                                    <tr>
                                        <td style="font-size:1px;line-height:1px" height="30">&nbsp;</td>
                                    </tr>
                                </tbody>
                            </table>

                        </td>
                    </tr>
                </tbody>
            </table>
            

            
            <table style="max-width:600px" width="100%" cellspacing="0" cellpadding="0" border="0">
                <tbody>
                    <tr>
                        <td valign="top" align="center">
                            
                            <table width="100%" cellspacing="0" cellpadding="0" border="0">
                                <tbody>
                                    <tr>
                                        <td style="padding-top:10px;padding-bottom:10px;padding-left:10px;padding-right:10px" valign="top" align="center">
                                            
                                            <a href="#m_-2033841538094845514_facebook-link" style="display:inline-block">
                                                <img src="https://ci4.googleusercontent.com/proxy/T1TQIISjXlVuID3_Eub3YCzfjM2L8XsQTME0QBWa9lQewdYf2zvFODrwG66Ts-P9fYxt1XtLU01kPErYPZq9T0ABiX0jkalEr7jwdp-wV15Pd7U1cw=s0-d-e1-ft#http://weekly.grapestheme.com/notify/img/social/light/facebook.png" alt="" style="height:auto;width:100%;max-width:40px;margin-left:2px;margin-right:2px" class="CToWUd" width="40" border="0">
                                            </a>
                                            
                                            <a href="#m_-2033841538094845514_twitter-link" style="display:inline-block">
                                                <img src="https://ci3.googleusercontent.com/proxy/FGDMhHLdv-cYdas7reZRED_tMUxlPSshpGXysEpWaOOC5qoXXEIB0pUaWA631MkfBTkOx6wb8a-DqSSxsRyK6UT8YnmOdE__JckyRiCArq1BTvrf=s0-d-e1-ft#http://weekly.grapestheme.com/notify/img/social/light/twitter.png" alt="" style="height:auto;width:100%;max-width:40px;margin-left:2px;margin-right:2px" class="CToWUd" width="40" border="0">
                                            </a>
                                            

                                            
                                            <a href="#m_-2033841538094845514_instagram-link" style="display:inline-block">
                                                <img src="https://ci3.googleusercontent.com/proxy/MovlNoe478F6Ked7kVmIOIrXBeXLSbh-uXTjQkBPxnueOxY9z5RlTrtD3CIav6q241NSuOTdgh6QMUCFErEWN-XXG08qhsALrkKi6u0PNdXg50uDx24=s0-d-e1-ft#http://weekly.grapestheme.com/notify/img/social/light/instagram.png" alt="" style="height:auto;width:100%;max-width:40px;margin-left:2px;margin-right:2px" class="CToWUd" width="40" border="0">
                                            </a>
                                            

                                        </td>
                                    </tr>

                                    <tr>
                                        <td style="padding:10px 10px 5px" valign="top" align="center">
                                            
                                            <p style="color:#777777;font-family:\'Open Sans\',Helvetica,Arial,sans-serif;font-size:12px;font-weight:400;font-style:normal;letter-spacing:normal;line-height:20px;text-transform:none;text-align:center;padding:0;margin:0">
                                                ©&nbsp;Daxy Private Limited. | 11, E S Patanwala Marg, Byculla |
                                                Mumbai 400027, MH, INDIA.
                                            </p>
                                        </td>
                                    </tr>

                                    <tr>

                                    </tr>

                                    <tr>
                                        <td style="padding:0px 10px 10px" valign="top" align="center">
                                            
                                            <p style="color:#777777;font-family:\'Open Sans\',Helvetica,Arial,sans-serif;font-size:12px;font-weight:400;font-style:normal;letter-spacing:normal;line-height:20px;text-transform:none;text-align:center;padding:0;margin:0">
                                                If you have any quetions please contact us <a href="mailto:hello@daxy.in" style="color:#777777;text-decoration:underline" target="_blank">hello@daxy.in</a> </p>
                                        </td>
                                    </tr>

                                    <tr>

                                    </tr>

                                    
                                    <tr>
                                        <td style="font-size:1px;line-height:1px" height="30">&nbsp;</td>
                                    </tr>
                                </tbody>
                            </table>
                            
                        </td>
                    </tr>

                    
                    <tr>
                        <td style="font-size:1px;line-height:1px" height="30">&nbsp;</td>
                    </tr>
                </tbody>
            </table>
            </div>
            </body>
            
        ';
              
            /* SMTP server name, port, user/passwd */  
            $smtpinfo["host"] = "mail.thekidszone.in";  
            $smtpinfo["port"] = "587";  
            $smtpinfo["auth"] = true;  
            $smtpinfo["username"] = "no-reply@thekidszone.in";  
            $smtpinfo["password"] = "b{TUKtPVR7a6";  
                
              
            $smtp = Mail::factory('smtp', $smtpinfo );  
            //$smtp->addHTMLImage("./images/2.jpg");
            //$mail = $smtp->send($to, $headers, $body);  
            //$smtp->send($to1, $headers, $body);
            //$smtp->send($to2, $headers, $body);
        
                    $headers = array ('From' => $from,'To' => $email,'Content-type' =>'text/html','Subject' => $subject);
                    $mail = $smtp->send($email, $headers, $message);
                
        
            if (PEAR::isError($mail)) {  
              echo("<p>" . $mail->getMessage() . "</p>");  
             } else {  
            //   echo("<p>Message successfully sent!</p>");  
            header("Location: ../password_recover.php?mail=sent");
            exit();
             }
            }else{
                header("Location:../password_recover.php?mail=invalid");
                exit();
            }
?>