<?php
include_once('../connect.php');
if (isset($_POST['submit'])) {
    $id = $_POST['id'];
    
    $pass = mysqli_real_escape_string($conn, $_POST['email']);
    $cpass = mysqli_real_escape_string($conn, $_POST['email2']);

if(strcmp($pass,$cpass) !== 0) {
            //Check if both passwords match
            Header("Location: ../changepass.php?id=".$id);
            exit();
        } else {
            $hashedPass = password_hash($pass, PASSWORD_DEFAULT);
                
                $sql = "UPDATE admin SET password='$hashedPass' WHERE username='".$id."';";
                // var_dump($sql);
                mysqli_query($conn, $sql) or die(mysqli_error($conn));
                
        Header("Location: ../password_recover.php?stat=changed");
            exit();
            
        }
}else{
    Header("Location: ../password_recover.php?stat=direct");
            exit();
}

?>