<?php
include_once('../connect.php');
$id=$_GET['submit'];
$name = ucfirst(mysqli_real_escape_string($conn, $_GET['c_name']));
// var_dump($name);
 $gen = mysqli_real_escape_string($conn, $_GET['gender']);
 
 $fname = ucfirst(mysqli_real_escape_string($conn, $_GET['fname']));
 $f_age = mysqli_real_escape_string($conn, $_GET['f_age']);
 $f_qual = mysqli_real_escape_string($conn, $_GET['f_qual']);
 $f_prof = mysqli_real_escape_string($conn, $_GET['f_prof']);
 $f_phone = mysqli_real_escape_string($conn, $_GET['f_phone']);
 

 $mname = ucfirst(mysqli_real_escape_string($conn, $_GET['mname']));
 $m_age = mysqli_real_escape_string($conn, $_GET['m_age']);
 $m_qual = mysqli_real_escape_string($conn, $_GET['m_qual']);
 $m_prof = mysqli_real_escape_string($conn, $_GET['m_prof']);
 $m_phone = mysqli_real_escape_string($conn, $_GET['m_phone']);

 $dob = mysqli_real_escape_string($conn, $_GET['cbirth_date']);
 $pob = mysqli_real_escape_string($conn, $_GET['cbirth']);
 // $religion = mysqli_real_escape_string($conn, $_GET['religion']);
 // $cast = mysqli_real_escape_string($conn, $_GET['cast']);

 $address = ucfirst(mysqli_real_escape_string($conn, $_GET['p_address']));
 $pincode = mysqli_real_escape_string($conn, $_GET['pincode']);
 $email = mysqli_real_escape_string($conn, $_GET['email']);
 $date = mysqli_real_escape_string($conn, $_GET['date']);
 // $phone = mysqli_real_escape_string($conn, $_GET['phone']);
 $refrence = mysqli_real_escape_string($conn, $_GET['refrence']);
//  var_dump($refrence);
//  $date=date("Y-m-d");
 // $place = mysqli_real_escape_string($conn, $_GET['place']);
 $branch = mysqli_real_escape_string($conn, $_GET['branch']);
 $batch = mysqli_real_escape_string($conn, $_GET['batch']);
 $btime = mysqli_real_escape_string($conn, $_GET['btime']);
$sql2="UPDATE `user` SET `name`='$name',`gender`='$gen',`fname`='$fname',`f_age`='$f_age',`f_qual`='$f_qual',`f_prof`='$f_prof',`f_phone`='$f_phone',`mname`='$mname',`m_age`='$m_age',`m_qual`='$m_qual',`m_prof`='$m_prof',`m_phone`='$m_phone',`dob`='$dob',`pob`='$pob',`p_address`='$address',`pincode`='$pincode',`refrence`='$refrence',`email`='$email',`date`='$date',`branch`='$branch',`batch`='$batch',`btime`='$btime' WHERE `id`=".$id;
//   var_dump($sql2);
    mysqli_query($conn, $sql2) or die(mysqli_error($conn));
    header("Location:../admin.php?stat=changed"); 
  exit(); 
    echo "<script>window.open('../admin.php?stat=changed','_self')</script>";

?>