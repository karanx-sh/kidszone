<?php
include_once('header.php');
$id=$_GET['id'];
$sql3="SELECT * FROM user WHERE id=".$id; 
$result3=mysqli_query($conn,$sql3);
$row3 = mysqli_fetch_assoc($result3);
?>
    <div id="content" class="main-content">
        <div class="container mt-5 mb-5">
        <form  action="inc/edit.php" mehtod="POST">
            <div class="form-group mb-4">
        <label for="inputAddress">Name of child</label>
        <input name="c_name" type="text" class="form-control" id="inputAddress" value="<?php echo $row3['name']?>" required>
    </div>
    <div class="form-row mb-4">
        <div class="form-group col-md-6">
            <label for="inputState">Child gender</label>
            <select name="gender" id="inputState" class="form-control">
                
                <?php
                if($row3['gender']=='MALE'){
                  echo '<option selected>MALE</option>
                <option>FEMALE</option>';  
                }else{
                    echo '<option>MALE</option>
                <option  selected>FEMALE</option>';
                }
                ?>
            
            </select>
        </div>
        <div class="form-group col-md-6">
            <label for="inputPassword4">Birth Date</label>
            <input name="cbirth_date" class="form-control" type="date" name="dob" value="<?php echo $row3['dob']?>" required>
        </div>
    </div>
    <div class="form-group mb-4">
        <label for="inputAddress">Child birth place</label>
        <input name="cbirth" type="text" class="form-control" id="inputAddress" value="<?php echo $row3['pob']?>" required>
    </div>
    <div class="form-group mb-4">
        <label for="inputAddress2">Parent address</label>
        <input name="p_address" type="text" class="form-control" id="inputAddress2" value="<?php echo $row3['p_address']?>" required>
    </div>
    <div class="form-row ">
        <div class="form-group col-md-6">
            <label for="inputCity">pincode</label>
            <input name="pincode" type="number" class="form-control" id="inputCity" value="<?php echo $row3['pincode']?>" required>
        </div>
    
    </div>
        <div class="form-group mb-4">
        <label for="inputAddress2">Mother name</label>
        <input name="mname" type="text" class="form-control" id="inputAddress2" value="<?php echo $row3['mname']?>" required>
    </div>
    <div class="form-row ">
        <div class="form-group col-md-6">
            <label for="inputCity">Mother age</label>
            <input name="m_age" type="number" class="form-control" id="inputCity" value="<?php echo $row3['m_age']?>" required>
        </div>
        
        <div class="col-md-6">
            <label for="inputZip">Mother qualification</label>
            <input name="m_qual" type="text" class="form-control" id="inputZip" value="<?php echo $row3['m_qual']?>" required>
        </div>
    </div>
    <div class="form-row ">
        <div class="form-group col-md-6">
            <label for="inputCity">Mother profession</label>
            <input name="m_prof" type="text" class="form-control" id="inputCity" value="<?php echo $row3['m_prof']?>" required>
        </div>
        
        <div class="col-md-6">
            <label for="inputZip">Mother phone</label>
            <input name="m_phone" type="number" class="form-control" id="inputZip" value="<?php echo $row3['m_phone']?>" required>
        </div>
    </div>
    
    
    <div class="form-group mb-4">
        <label for="inputAddress2">Father name</label>
        <input name="fname" type="text" class="form-control" id="inputAddress2" value="<?php echo $row3['fname']?>" required>
    </div>
    <div class="form-row ">
        <div class="form-group col-md-6">
            <label for="inputCity">Father age</label>
            <input name="f_age" type="number" class="form-control" id="inputCity" value="<?php echo $row3['f_age']?>" required>
        </div>
        
        <div class="col-md-6">
            <label for="inputZip">Father qualification</label>
            <input name="f_qual" type="text" class="form-control" id="inputZip" value="<?php echo $row3['f_qual']?>" required>
        </div>
    </div>
    <div class="form-row ">
        <div class="form-group col-md-6">
            <label for="inputCity">Father profession</label>
            <input name="f_prof" type="text" class="form-control" id="inputCity" value="<?php echo $row3['f_prof']?>" required>
        </div>
        
        <div class="col-md-6">
            <label for="inputZip">Father phone</label>
            <input name="f_phone" type="number" class="form-control" id="inputZip" value="<?php echo $row3['f_phone']?>" required>
        </div>
    </div>
      <div class="form-group mb-4">
        <label for="inputAddress">Email</label>
        <input name="email" type="text" class="form-control" id="inputAddress" value="<?php echo $row3['email']?>" required>
        <input name="date" type="text" class="form-control" id="inputAddress" value="<?php echo $row3['date']?>" hidden>
        <!--<input name="refrence" type="text" class="form-control" id="inputAddress" value="<?php 
        // echo $row3['refrence']
        ?>">-->
    </div>
    
    
    <div class="wrap-input100 input100-select bg1">
					<p>
						<span class="label-input100">BRANCH *</span>
						<div>
							<select id="branch" class="form-control js-select2" name="branch" required>
                                <?php
                if($row3['batch']=='BYCULLA'){
                  echo '<option selected>BYCULLA</option>
								<option>KALACHOWKY</option>
								<option>SEWREE</option>
								<option>WORLI</option>';  
                }elseif($row3['batch']=='KALACHOWKY'){
                    echo '<option>BYCULLA</option>
								<option selected>KALACHOWKY</option>
								<option>SEWREE</option>
								<option>WORLI</option>';
                }elseif($row3['batch']=='SEWREE'){
                    echo '<option>BYCULLA</option>
								<option>KALACHOWKY</option>
								<option selected>SEWREE</option>
								<option>WORLI</option>';
                }else{
                    echo '<option>BYCULLA</option>
								<option>KALACHOWKY</option>
								<option>SEWREE</option>
								<option selected>WORLI</option>';
                }
                ?>
								<!--<option>BYCULLA</option>-->
								<!--<option>KALACHOWKY</option>-->
								<!--<option>SEWREE</option>-->
								<!--<option>WORLI</option>-->
							</select>
							<div class="dropDownSelect2"></div>
							<!--<a href="https://thekidszone.in/contact-us"-->
							<!--	style="font-family: Montserrat-SemiBold; text-transform: uppercase; text-decoration: underline;"-->
							<!--	target="_blank ">ADDRESS-->
							<!--	AND-->
							<!--	Details</a>-->
					</p>
				</div>
		</div>



		<div class="wrap-input100 input100-select bg1 rs1-wrap-input100">
			<span class="label-input100">BATCH *</span>
			<div>
				<select id="batch" class=" form-control js-select2" name="batch" required>
<?php
                if($row3['batch']=='PLAYGROUP'){
                  echo '<option selected>PLAYGROUP</option>
					<option>NURSERY</option>
					<option>JRSRKG</option>';  
                }elseif($row3['batch']=='NURSERY'){
                    echo '<option>PLAYGROUP</option>
					<option selected>NURSERY</option>
					<option>JRSRKG</option>';
                }elseif($row3['batch']=='JRSRKG'){
                    echo '<option>PLAYGROUP</option>
					<option>NURSERY</option>
					<option selected>JRSRKG</option>';
                }
                ?>
					
				</select>
				<div class="dropDownSelect2"></div>
			</div>
		</div>


		<div class="wrap-input100 input100-select bg1 rs1-wrap-input100">
			<span class="label-input100">BATCH TIMING*</span>
			<div>
				<select id="timing" class="form-control js-select2" name="btime" required>
				    <?php
                
                  echo '<option selected>'.$row3['btime'].'</option>
            ';  
                
                ?>
				</select>
				<div class="dropDownSelect2"></div>
			</div>
		</div>



<span class="label-input100">Refrence*</span>
<div class="form-group mt-2 mb-4">
    
    <select id="refrence" class="form-control" name="refrence" required>
                                <?php
                if($row3['refrence']=='WEBSITE'){
                  echo '<option selected>WEBSITE</option>
					<option>BANNER</option>
					<option>PAMPHLET</option>
					<option>FACEBOOK, OTHER SOCIAL MEDIA</option>
					<option>FRIENDS AND RELATIVES</option>';  
                }elseif($row3['refrence']=='BANNER'){
                    echo '<option>WEBSITE</option>
					<option selected>BANNER</option>
					<option>PAMPHLET</option>
					<option>FACEBOOK, OTHER SOCIAL MEDIA</option>
					<option>FRIENDS AND RELATIVES</option>';
                }elseif($row3['refrence']=='PAMPHLET'){
                    echo '<option>WEBSITE</option>
					<option>BANNER</option>
					<option selected>PAMPHLET</option>
					<option>FACEBOOK, OTHER SOCIAL MEDIA</option>
					<option>FRIENDS AND RELATIVES</option>';
                }elseif($row3['refrence']=='FACEBOOK, OTHER SOCIAL MEDIA'){
                    echo '<option >WEBSITE</option>
					<option>BANNER</option>
					<option>PAMPHLET</option>
					<option selected>FACEBOOK, OTHER SOCIAL MEDIA</option>
					<option>FRIENDS AND RELATIVES</option>';
                }else{
                    echo '<option>WEBSITE</option>
					<option>BANNER</option>
					<option>PAMPHLET</option>
					<option>FACEBOOK, OTHER SOCIAL MEDIA</option>
					<option selected>FRIENDS AND RELATIVES</option>';
                }
                ?>
						
							</select>
    </div>
    
  <button value="<?php echo $id;?>" name="submit" type="submit" class="btn btn-primary mt-3">Submit</button>
</form>
</div>
</div>

<?php
include_once('footer.php');
?>
<!--<script src="../vendor/select2/select2.min.js"></script>-->
	<script>
		$(".js-select2").each(function () {
			$(this).select2({
				minimumResultsForSearch: 20,
				dropdownParent: $(this).next('.dropDownSelect2')
			});


			$(".js-select2").each(function () {
				$(this).on('select2:close', function (e) {
					if ($(this).val() == "Please chooses") {
						$('.js-show-service').slideUp();
					}
					else {
						$('.js-show-service').slideUp();
						$('.js-show-service').slideDown();
					}
				});
			});
		})
	</script>
	<script>

		let branchv = '',
			batchv = '';
		let timings = {
			WORLI: {
				PLAYGROUP: '11:30 AM to 1:30 PM',
				NURSERY: ['09:00 AM to 11:00 AM', '11:30 AM TO 02:00 PM'],
				JRSRKG: '08:30 AM TO 11:00 AM'
			}
			,
			KALACHOWKY: {
				PLAYGROUP: '09:00 AM to 11:00 AM',
				NURSERY: '11:30 AM to 02:00 PM',
				JRSRKG: '02:30 PM TO 04:30 PM'
			},

			SEWREE: {
				PLAYGROUP: '09:00 AM to 11:00 AM',
				NURSERY: '11:30 AM to 02:00 PM',
				JRSRKG: '08:30 AM TO 11:00 AM'
			},

			BYCULLA: {
				PLAYGROUP: '09:00 AM to 11:00 AM',
				NURSERY: ['08:30 AM to 11:00 AM', '11:30 AM TO 02:00 PM'],
				JRSRKG: '02:30 PM TO 05:00 PM'

			}
		}
		let timingContainer = document.querySelector('#timing');

		$('#branch').change(() => {
			batchv = $('#batch').val();
			branchv = $('#branch').val();
			addOptions(timings[branchv][batchv]);
		});

		$('#batch').change(() => {

			batchv = $('#batch').val();
			branchv = $('#branch').val();
			addOptions(timings[branchv][batchv]);

		});

		let addOptions = (arr) => {
			timingContainer.innerHTML = '';
			if (Array.isArray(arr)) {
				arr.forEach(e => {
					timingContainer.insertAdjacentHTML("beforeend", `<option>${e}</option>`);
				});
			} else {
				timingContainer.insertAdjacentHTML("beforeend", `<option>${arr}</option>`);
			}

		}
	</script>
