<?php
include_once('connect.php');
// include_once('header.php');
session_start();
if ($_SESSION['privilege']== 'admin' || $_SESSION['privilege']== 'assistant') {
// echo "fhwei";
}else{
  header("Location:index.php?login=error"); 
  exit(); 
    echo "<script>window.open('index.php?login=error','_self')</script>";
}
$id=$_GET['id'];
if(!empty($id)){
    $sql3="SELECT * FROM user WHERE id=".$id; 
$result3=mysqli_query($conn,$sql3);
$row3 = mysqli_fetch_assoc($result3);
}else{
    header("Location: admin.php?stat=id"); 
  exit();
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
	<title>Admission Form - Kidszone</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	
	 <!-- Favicon -->
    <link rel="apple-touch-icon" sizes="57x57" href="https://daxy.in/img/favicon/apple-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="https://daxy.in/img/favicon/apple-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="https://daxy.in/img/favicon/apple-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="https://daxy.in/img/favicon/apple-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="https://daxy.in/img/favicon/apple-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="https://daxy.in/img/favicon/apple-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="https://daxy.in/img/favicon/apple-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="https://daxy.in/img/favicon/apple-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="https://daxy.in/img/favicon/apple-icon-180x180.png">
    <link rel="icon" type="image/png" sizes="192x192" href="https://daxy.in/img/favicon/android-icon-192x192.png">
    <link rel="icon" type="image/png" sizes="32x32" href="https://daxy.in/img/favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="96x96" href="https://daxy.in/img/favicon/favicon-96x96.png">
    <link rel="icon" type="image/png" sizes="16x16" href="https://daxy.in/img/favicon/favicon-16x16.png">
    <link rel="manifest" href="https://daxy.in/img/favicon/manifest.json">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="https://daxy.in/img/ms-icon-144x144.png">
    <meta name="theme-color" content="#ffffff">
	<!--===============================================================================================-->
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../vendor/bootstrap/css/bootstrap.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../fonts/font-awesome-4.7.0/css/font-awesome.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../fonts/iconic/css/material-design-iconic-font.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../vendor/animate/animate.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../vendor/css-hamburgers/hamburgers.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../vendor/animsition/css/animsition.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../vendor/select2/select2.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../vendor/daterangepicker/daterangepicker.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../vendor/noui/nouislider.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../css/util.css">
	<link rel="stylesheet" type="text/css" href="../css/main.css">
	<!--===============================================================================================-->
</head>

<body>

<?php
$stat=$_GET['error'];
if ($stat=='false') {
   echo "<script>swal({
      title: 'Thank You!',
      text: 'Form submitted successfully',
      type: 'success',
      padding: '2em'
    })</script>";  
}elseif ($stat=='true') {
	$stat=$_GET['details'];

    echo "<script>swal({
           title: 'Something went wrong!',
      text: '".$stat."',
      type: 'question',
      padding: '2em'
        })</script>";
}
?>
	<div class="container-contact100">
		<div class="wrap-contact100">
			<form class="contact100-form validate-form" action="#" method="POST">
				<span class="contact100-form-title">
					ADMISSION FORM
				
					<span class="label-input100">Form id: <?php echo date("ymd",strtotime($row3['date'])).$row3['id']; ?></span>
				</span>
				
				
				
				<!-- <div class="wrap-input100 bg0 ">
					<p>Ullam perferendis ex
						CONTACT DETAILS: <br>
						1. Kalachowki- +91 8291550999<br>
						2. Byculla- +91 8291550888<br>
						3. Sewri- +91 8291550777<br>
						4. Worli- +91 8291550666<br>
					</p>
				</div> -->
				<div class="wrap-input100 validate-input bg1" data-validate="PLEASR TYPE YOUR CHILD'S NAME">
					<span class=" label-input100">CHILD'S NAME *</span>
					<input class="input100" type="text" name="name" value="<?php echo $row3['name']; ?>" style="text-transform: uppercase;" readonly>
						
				</div>

				<div class="wrap-input100 input100-select bg1 rs1-wrap-input100"
					data-validate="PLEASE SELECT YOUR CHILD'S GENDER">
					<span class="label-input100">CHILD'S GENDER *</span>
					<div>
					    <input class="input100" type="text" name="name" value="<?php echo $row3['gender'];?>" readonly>
						
						<div class="dropDownSelect2"></div>
					</div>
				</div>

				<div class="wrap-input100 validate-input bg1 rs1-wrap-input100"
					data-validate="PLEASE SELECT YOUR CHILD'S BIRTHDATE">
					<span class="label-input100">CHILD'S BIRTH DATE *</span>
					<input class="input100" type="date" name="dob" value="<?php echo $row3['dob']?>" readonly style="text-transform: uppercase;">
				</div>

				<div class="wrap-input100 validate-input bg1 rs1-wrap-input100"
					data-validate="PLEASE TYPE YOUR CHILD'S BIRTHPLACE">
					<span class="label-input100">CHILD'S BIRTH PLACE *</span>
					<input class="input100" type="text" name="pob" value="<?php echo $row3['pob']?>" readonly
						style="text-transform: uppercase;">
				</div>

				<div class="wrap-input100 validate-input bg1 rs1-alert-validate"
					data-validate="PLEASE TYPE YOUR PERMANENT ADDRESS">
					<span class="label-input100">PERMANENT ADDRESS *</span>
					<input class="input100" name="address" value="<?php echo $row3['p_address']?>" readonly
						style="text-transform: uppercase;">
				</div>

				<div class="wrap-input100 validate-input bg1 rs1-wrap-input100"
					data-validate="ENTER YOUR PINCODE OF YOUR RESPECTIVE AREA">
					<span class="label-input100">PINCODE *</span>
					<input class="input100" type="number" name="pincode" value="<?php echo $row3['pincode']?>" readonly
						style="text-transform: uppercase;">
				</div>

				<div class="wrap-input100 validate-input bg1" data-validate="PLEASE TYPE MOTHER'S NAME">
					<span class="label-input100">MOTHER's NAME *</span>
					<input class="input100" type="text" name="mname" value="<?php echo $row3['mname']?>" readonly>
				</div>

				<div class="wrap-input100 validate-input bg1 rs1-wrap-input100"
					data-validate="PLEASE TYPE MOTHER'S AGE">
					<span class="label-input100">MOTHER's AGE *</span>
					<input class="input100" type="number" minlength="2" maxlength="2" name="m_age" value="<?php echo $row3['m_age']?>"
						readonly>
				</div>

				<div class="wrap-input100 validate-input bg1 rs1-wrap-input100"
					data-validate="PLEASE TYPE MOTHER'S QUALIFICATION">
					<span class="label-input100">MOTHER's QUALIFICATION *</span>
					<input class="input100" type="text" name="m_qual"  value="<?php echo $row3['m_qual']?>"  readonly>
				</div>

				<div class="wrap-input100 validate-input bg1 rs1-wrap-input100"
					data-validate="PLEASE TYPE MOTHER'S PROFESSION">
					<span class="label-input100">MOTHER's PROFESSION *</span>
					<input class="input100" type="text" name="m_prof" value="<?php echo $row3['m_prof']?>" readonly>
				</div>

				<div class="wrap-input100 validate-input bg1 rs1-wrap-input100"
					data-validate="PLEASE TYPE MOTHER'S PHONE">
					<span class="label-input100">MOTHER's PHONE *</span>
					<input class="input100" type="number" minlength="10" maxlength="10" name="m_phone" value="<?php echo $row3['m_phone']?>"
						readonly>
				</div>

				<div class="wrap-input100 validate-input bg1" data-validate="PLEASE TYPE FATHER'S NAME">
					<span class="label-input100">FATHER's NAME *</span>
					<input class="input100" type="text" name="fname" value="<?php echo $row3['fname']?>" readonly>
				</div>

				<div class="wrap-input100 validate-input bg1 rs1-wrap-input100"
					data-validate="PLEASE TYPE FATHER'S AGE">
					<span class="label-input100">FATHER's AGE *</span>
					<input class="input100" type="number" minlength="2" maxlength="2" name="f_age" value="<?php echo $row3['f_age']?>"
						readonly>
				</div>

				<div class="wrap-input100 validate-input bg1 rs1-wrap-input100"
					data-validate="PLEASE TYPE FATHER'S QUALIFICATION">
					<span class="label-input100">FATHER's QUALIFICATION *</span>
					<input class="input100" type="text" name="f_qual" value="<?php echo $row3['f_qual']?>" readonly>
				</div>

				<div class="wrap-input100 validate-input bg1 rs1-wrap-input100"
					data-validate="PLEASE TYPE FATHER'S PROFESSION">
					<span class="label-input100">FATHER's PROFESSION *</span>
					<input class="input100" type="text" name="f_prof" value="<?php echo $row3['f_prof']?>" readonly>
				</div>


				<div class="wrap-input100 validate-input bg1 rs1-wrap-input100"
					data-validate="PLEASE TYPE FATHER'S PHONE">
					<span class="label-input100">FATHER's PHONE *</span>
					<input class="input100" type="number" name="f_phone" minlength="10" maxlength="10" value="<?php echo $row3['f_phone']?>"
						readonly>
				</div>


				<div class="" style="width: 100%;">
					<div class="wrap-input100 validate-input bg1 rs1-wrap-input100"
						data-validate="Enter Your Email address">
						<span class="label-input100">Email *</span>
						<input class="input100" type="text" name="email" value="<?php echo $row3['email']?>" readonly>
					</div>
				</div>

				<br>

				<div class="wrap-input100 input100-select bg1">
					<p>
						<span class="label-input100">BRANCH *</span>
						<div>
						    
						<input class="input100" type="text" name="email" value="<?php echo$row3['branch']?>" readonly>
					</p>
				</div>
		</div>



		<div class="wrap-input100 input100-select bg1 rs1-wrap-input100">
			<span class="label-input100">BATCH *</span>
			<div>
					<input class="input100" type="text" name="email" value="<?php echo$row3['batch']?>" readonly>
							</div>
		</div>


		<div class="wrap-input100 input100-select bg1 rs1-wrap-input100">
			<span class="label-input100">BATCH TIMING*</span>
			<div>
					<input class="input100" type="text" name="email" value="<?php echo$row3['btime']?>" readonly>
			</div>
		</div>




		<div style="margin-top: 40px;" class="wrap-input100 input100-select bg1 rs1-wrap-input100">
			<span class="label-input100">How did you find us?</span>
			<div>
			
			<input class="input100" type="text" name="email" value="<?php echo$row3['refrence']?>" readonly>
			</div>
		</div>


		<!-- <div class="wrap-input100 bg0 ">
			<p>
				By submitting the form, I certify that I have read, understand, and adhere to all
				applicable guidelines and agreements and the information that i have given is True.

			</p>
		</div> -->



		<!-- <div class="container-contact100-form-btn">
			<button class="contact100-form-btn">
				<span>
					Submit
					<i class="fa fa-long-arrow-right m-l-7" aria-hidden="true"></i>
				</span>
			</button>
		</div> -->
		</form>

		<div>

		</div>
		<!-- <div class="wrap-input100 bg0 " style="margin-top: 40px;;">
			<p>
				NOTE: <br>
				1. ONCE THE FORM IS SUBMITTED, WE'LL SEND YOU A CONFIRMATION MESSAGE.<br>
				2. FOR PAYMENT DETAILS CONTACT THE PERSONNEL ASSIGNED.<br>
				3. ASSIGNED PERSONNELS CONTACT NUMBER WILL BE SENT TO YOU BY TEXT.<br>
				4. FORM WILL BE CONFIRMED AFTER SUCCESSFULL PAYMENT ONLY.<br>
				5. Documents to be submitted before joining! 4 photograph, Birth Certificate, Address Proof, Aadhar card
				of
				both parents
			</p>
		</div> -->
		<p style="text-align: center; margin-top: 50px;">Handcrafted with ❤️ by <a href="https://daxy.in"
				style="font-family: Montserrat-SemiBold; text-transform: uppercase; text-decoration: underline;">Team
				Daxy</a>.</p>
	</div>

	</div>

	<footer>

	</footer>

	<!--===============================================================================================-->
	<script src="../vendor/jquery/jquery-3.2.1.min.js"></script>
	<!--===============================================================================================-->
	<script src="../vendor/animsition/js/animsition.min.js"></script>
	<!--===============================================================================================-->
	<script src="../vendor/bootstrap/js/popper.js"></script>
	<script src="../vendor/bootstrap/js/bootstrap.min.js"></script>
	<!--===============================================================================================-->
	<script src="../vendor/select2/select2.min.js"></script>
	
	<!--===============================================================================================-->
	<script src="../vendor/daterangepicker/moment.min.js"></script>
	<script src="../vendor/daterangepicker/daterangepicker.js"></script>
	<!--===============================================================================================-->
	<script src="../vendor/countdowntime/countdowntime.js"></script>
	<!--===============================================================================================-->
	<script src="../vendor/noui/nouislider.min.js"></script>
	<!--===============================================================================================-->
	<script src="../js/main.js"></script>
	

</body>

</html>