<?php
date_default_timezone_set('Asia/Kolkata');
include_once('connect.php');
function my_simple_crypt( $string, $action ) {
    // you may change these values to your own
    $secret_key = 'my_simple_secret_key';
    $secret_iv = 'my_simple_secret_iv';
 
    $output = false;
    $encrypt_method = "AES-256-CBC";
    $key = hash( 'sha256', $secret_key );
    $iv = substr( hash( 'sha256', $secret_iv ), 0, 16 );
 
    if( $action == 'e' ) {
        $output = base64_encode( openssl_encrypt( $string, $encrypt_method, $key, 0, $iv ) );
    }
    else if( $action == 'd' ){
        $output = openssl_decrypt( base64_decode( $string ), $encrypt_method, $key, 0, $iv );
    }
 
    return $output;
}
$time=my_simple_crypt($_GET['time'],'d');
$id=my_simple_crypt($_GET['id'],'d');
// // $timestamp = strtotime($time);

// // var_dump($time);

// // $time= ;
// $atime = strtotime(date('Y-m-d H:i:s',time()));
// echo $atime;
// $oldDate = $time + 900; // 86400 seconds in 24 hrs
//   var_dump($oldDate);          
//             if($oldDate < $atime)
//             {
//                 echo "link expired";
//             }else{
//                 echo "link is active";
//             }
$sql="SELECT * FROM admin WHERE username='$id';"; 
        $result=mysqli_query($conn,$sql);
        $row = mysqli_fetch_assoc($result);
        $check=mysqli_num_rows($result);
        if($check = 1){
            date_default_timezone_set('Asia/Kolkata');

            
            $timestamp = $time; //1373673600
            
            // getting current date 
            $cDate = strtotime(date('Y-m-d H:i:s'));
            
            // Getting the value of old date + 24 hours
            $oldDate = $timestamp + 900; // 86400 seconds in 24 hrs
            
            if($oldDate < $cDate)
            {
                header("Location: password_recover.php?mail=time1");
                exit();
            }
            else
            { 
     header("Location: changepass.php?id=".$id);
                exit();
            }


        }else{
            header("Location: password_recover.php?mail=time2");
            exit();   
        }
?>