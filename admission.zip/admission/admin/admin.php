<?php
include_once('header.php');
?>    <!--  BEGIN MAIN CONTAINER  -->

<!--  BEGIN CONTENT AREA  -->
        <div id="content" class="main-content">
            <div class="layout-px-spacing">                
                <div class="row layout-spacing layout-top-spacing" id="cancel-row">
                    <div class="col-lg-12">
                        <div class="statbox widget box box-shadow">
                            <div class="widget-header">
                                <div class="row">
                                    <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                                        <h4>Registered users</h4>
                                    </div>
                                </div>
                            </div>
                            <div class="widget-content widget-content-area">
                                <div class="table-responsive mb-4">
                                    <table id="style-3" class="table style-3  table-hover non-hover">
                                        <thead>
                                            <tr>
                                                <th class="text-center">Action</th>
                                                <th class="checkbox-column text-center"> Record Id </th>
                                                <th>Name</th>
                                                <th>Gender</th>
                                                <th>DOB</th>
                                                <th>POB</th>
                                                <th>Father name</th>
                                                <th>Father age</th>
                                                <th>Father qualification</th>
                                                <th>Father profession</th>
                                                <th>Father phone</th>
                                                <th>Mother name</th>
                                                <th>Mother age</th>
                                                <th>Mother qualification</th>
                                                <th>Mother profession</th>
                                                <th>Mother phone</th>
                                                <th>Email</th>
                                                <th>Address</th>
                                                <th>Pincode</th>
                                                
                                                <th>Date</th> 
                                                <th>Branch</th>
                                                <th>Batch</th>                       
                                                <th>Refrence</th>                        
                                                <!-- <th class="text-center">Status</th> -->
                                                
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
$stat=$_GET['stat'];
if ($stat=='app') {
   echo "<script>swal({
      title: 'Approved!',
      text: 'Record approved',
      type: 'success',
      padding: '2em'
    })</script>";  
}elseif ($stat=='changed') {
    echo "<script>swal({
      title: 'Data updated!',
      text: 'Record Updated',
      type: 'success',
      padding: '2em'
    })</script>";
}
elseif ($stat=='del') {
    echo "<script>swal({
           title: 'deleted!',
      text: 'Record has been deleted!',
      type: 'success',
      padding: '2em'
        })</script>";
}
if($_SESSION['privilege']=='admin'){
    $sql3="SELECT * FROM user WHERE status=0"; 
$result3=mysqli_query($conn,$sql3);
$check=mysqli_num_rows($result3);
}else{
$sql3="SELECT * FROM user WHERE status=0 AND branch ='".$_SESSION['branch']."'"; 
$result3=mysqli_query($conn,$sql3);
$check=mysqli_num_rows($result3);
}
if ($check>=1) {
                                             while ($row3 = mysqli_fetch_assoc($result3)) {?>
                                   <tr>
<div class="modal fade" id="<?php echo 'a'.$row3['id'];?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Are you sure</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <svg> ... </svg>
                </button>
            </div>
           
            <div class="modal-footer">
                <button class="btn" data-dismiss="modal"><i class="flaticon-cancel-12"></i> Discard</button>
                <a href="approve.php?id=<?php echo $row3['id'];?>" type="button" class="btn btn-primary">Approve</a>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="<?php echo 'd'.$row3['id'];?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Are you sure</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <svg> ... </svg>
                </button>
            </div>
           
            <div class="modal-footer">
                <button class="btn" data-dismiss="modal"><i class="flaticon-cancel-12"></i> Discard</button>
                <a href="delete.php?id=<?php echo $row3['id'];?>" type="button" class="btn btn-primary">Delete</a>
            </div>
        </div>
    </div>
</div>
<td class="text-center">
<div class="dropdown custom-dropdown">
                                                    <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink12" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-more-horizontal"><circle cx="12" cy="12" r="1"></circle><circle cx="19" cy="12" r="1"></circle><circle cx="5" cy="12" r="1"></circle></svg>
                                                    </a>
                                                    <div class="dropdown-menu" aria-labelledby="dropdownMenuLink12">
                                                    <a href="viewform.php?id=<?php echo $row3['id'];?>" class="bs-tooltip" data-toggle="tooltip" data-placement="top" title="" data-original-title="View"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-file"><path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"></path><polyline points="13 2 13 9 20 9"></polyline></svg></a>
                                                    <a href="edit.php?id=<?php echo $row3['id'];?>" class="bs-tooltip" data-toggle="tooltip" data-placement="top" title="" data-original-title="Edit"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-edit-2 p-1 br-6 mb-1"><path d="M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"></path></svg></a>
                                                    <a href="javascript:void(0);" class="bs-tooltip" data-toggle="modal" data-target="#<?php echo 'a'.$row3['id'];?>" data-placement="top" title="" data-original-title="Approve"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-check"><polyline points="20 6 9 17 4 12"></polyline></svg></a>
                                                    <a href="javascript:void(0);" class="bs-tooltip" data-toggle="modal" data-target="#<?php echo 'd'.$row3['id'];?>" data-placement="top" title="" data-original-title="Delete"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-trash p-1 br-6 mb-1"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg></a>
                                                    </div>
                                                </div>  
                                                    <!-- <ul class="table-controls">
                                                        <li><a href="edit.php?id=<?php echo $row3['id'];?>" class="bs-tooltip" data-toggle="tooltip" data-placement="top" title="" data-original-title="Edit"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-edit-2 p-1 br-6 mb-1"><path d="M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"></path></svg></a></li>
                                                        <li><a href="javascript:void(0);" class="bs-tooltip" data-toggle="modal" data-target="#<?php echo 'a'.$row3['id'];?>" data-placement="top" title="" data-original-title="Approve"><svg  xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M20.285 2l-11.285 11.567-5.286-5.011-3.714 3.716 9 8.728 15-15.285z"/></svg></a></li>
                                                        <li><a href="javascript:void(0);" class="bs-tooltip" data-toggle="modal" data-target="#<?php echo 'd'.$row3['id'];?>" data-placement="top" title="" data-original-title="Delete"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-trash p-1 br-6 mb-1"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg></a></li>
                                                    </ul> -->
                                                </td>   


<td class="checkbox-column text-center"><?php echo date("ymd",strtotime($row3['date'])).$row3['id']; ?></td>
<td><?php echo $row3['name']; ?></td>
<td><?php echo $row3['gender']; ?></td>
<td><?php echo $row3['dob']; ?></td>
<td><?php echo $row3['pob']; ?></td>
<td><?php echo $row3['fname']; ?></td>
<td><?php echo $row3['f_age']; ?></td>
<td><?php echo $row3['f_qual']; ?></td>
<td><?php echo $row3['f_prof']; ?></td>
<td><?php echo $row3['f_phone']; ?></td>
<td><?php echo $row3['mname']; ?></td>
<td><?php echo $row3['m_age']; ?></td>
<td><?php echo $row3['m_qual']; ?></td>
<td><?php echo $row3['m_prof']; ?></td>
<td><?php echo $row3['m_phone']; ?></td>
<td><?php echo $row3['email']; ?></td>
<td><?php echo $row3['p_address']; ?></td>
<td><?php echo $row3['pincode']; ?></td>
<td><?php echo $row3['date']; ?></td>
<td><?php echo $row3['branch']; ?></td>
<td><?php echo $row3['batch']; ?></td>  
<td><?php echo $row3['refrence']; ?></td>


 
                                                
                                                
                                            </tr>

                                            <?php
                                            }
                                        }else{
                                      echo 'No record found';

                                        }
                                            ?>
                                        
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="footer-wrapper">
                <div class="footer-section f-section-1">
                    <p class="">Copyright © 2020 <a target="_blank" href="https://daxy.in/">Daxy</a>, All rights reserved.</p>
                </div>
                <div class="footer-section f-section-2">
                    <p class="">Coded with <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-heart"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path></svg> Team Daxy</p>
                </div>
            </div>
        </div>
        <!--  END CONTENT AREA  -->
  <?php

include_once('footer.php');
  ?>