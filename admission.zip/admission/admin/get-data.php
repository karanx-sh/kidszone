<?php
header('Content-Type: application/json');
include_once('connect.php');
$json=array();
$sql="SELECT * FROM user"; 
        $result=mysqli_query($conn,$sql)or die("connection failed");
        while($row = mysqli_fetch_assoc($result)){
            $json[]=$row;
        }
        echo json_encode($json);
?>