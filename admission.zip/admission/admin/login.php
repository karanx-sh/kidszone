<?php
include_once('connect.php');
$username=$_POST['username'];
$password=$_POST['password'];
if(empty($username) || empty($password)) {
      header("Location: index.php?login=empty");
      exit(); 
    }else{
$sql="SELECT * FROM admin WHERE phone = '$username'"; 
        $result=mysqli_query($conn,$sql)or die($sql);
        $row = mysqli_fetch_assoc($result);
        $check=mysqli_num_rows($result);
        if($check >= 1){
            $password1 = $row['password'];

            if(password_verify($password, $password1)) {
                session_start();
                // echo $row['name'].'+'.$row['privilege'].'+'.$row['phone'].'+'.$row['BRANCH'];
                $_SESSION['user_name']=$row['name'];
                $_SESSION['privilege']=$row['privilege'];
                $_SESSION['user']=$row['phone'];
                $_SESSION['id']=$row['id'];
                $_SESSION['branch']=$row['BRANCH'];
                header("Location: admin.php?login=success");
      exit();
                
            }else{
                header("Location: index.php?login=password_incorrect");
      exit();
            }  
        }else{
                header("Location: index.php?login=invalid".$sql);
      exit();
            }

        
    }
?>