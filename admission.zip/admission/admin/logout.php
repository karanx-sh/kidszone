<?php
session_start();
session_unset();
session_destroy();
   
 echo "<script>window.open('index.php?stat=logout','_self')</script>";
 ?>