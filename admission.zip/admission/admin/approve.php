<?php
include_once('connect.php');
session_start();
if ($_SESSION['privilege']== 'admin' || $_SESSION['privilege']== 'assistant') {

}else{
  header("Location:index.php?login=error"); 
  exit(); 
    echo "<script>window.open('index.php?login=error','_self')</script>";
}
$id=$_GET['id'];
 $sql4="UPDATE `user` SET `status`=1 WHERE status=0  AND id=".$id;
 // echo $sql4;
 mysqli_query($conn, $sql4) or die(mysqli_error($conn));
header("Location:admin.php?stat=app"); 
  exit(); 
    echo "<script>window.open('admin.php?stat=app','_self')</script>";
?>