<?php
error_reporting(0);
ini_set('display_errors', 0);
header('Content-Type: application/json');

include_once('admin/connect.php');
$conn = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName) or die("Connection failed");
 $name = ucfirst(mysqli_real_escape_string($conn, $_POST['name']));
 $gen = mysqli_real_escape_string($conn, $_POST['gen']);
 
 $fname = ucfirst(mysqli_real_escape_string($conn, $_POST['fname']));
 $f_age = mysqli_real_escape_string($conn, $_POST['f_age']);
 $f_qual = mysqli_real_escape_string($conn, $_POST['f_qual']);
 $f_prof = mysqli_real_escape_string($conn, $_POST['f_prof']);
 $f_phone = mysqli_real_escape_string($conn, $_POST['f_phone']);
 

 $mname = ucfirst(mysqli_real_escape_string($conn, $_POST['mname']));
 $m_age = mysqli_real_escape_string($conn, $_POST['m_age']);
 $m_qual = mysqli_real_escape_string($conn, $_POST['m_qual']);
 $m_prof = mysqli_real_escape_string($conn, $_POST['m_prof']);
 $m_phone = mysqli_real_escape_string($conn, $_POST['m_phone']);

 $dob = mysqli_real_escape_string($conn, $_POST['dob']);
 $pob = mysqli_real_escape_string($conn, $_POST['pob']);
 // $religion = mysqli_real_escape_string($conn, $_POST['religion']);
 // $cast = mysqli_real_escape_string($conn, $_POST['cast']);

 $address = ucfirst(mysqli_real_escape_string($conn, $_POST['address']));
 $pincode = mysqli_real_escape_string($conn, $_POST['pincode']);
 $email = mysqli_real_escape_string($conn, $_POST['email']);
 // $phone = mysqli_real_escape_string($conn, $_POST['phone']);
 $refrence = mysqli_real_escape_string($conn, $_POST['reference']);
 $date=date("Y-m-d");
 // $place = mysqli_real_escape_string($conn, $_POST['place']);
 $branch = mysqli_real_escape_string($conn, $_POST['branch']);
 $batch = mysqli_real_escape_string($conn, $_POST['batch']);
 $btime = mysqli_real_escape_string($conn, $_POST['btime']);


$Aerror = array();
if(!isset( $name ) || empty($name) ) { 
 $error = array('code' => '404','name' => 'name', 'message' => 'name is empty'); 
 array_push($Aerror, $error);
}elseif (!isset( $gen) || empty($gen) ) {
	$error = array('code' => '404','name' => 'gen', 'message' => 'gender is empty'); 
 array_push($Aerror, $error);
}elseif (!isset( $fname) || empty($fname)) {
	$error = array('code' => '404','name' => 'fname', 'message' => 'father name is empty'); 
 array_push($Aerror, $error);
}elseif (!isset( $f_age) || empty($f_age)) {
	$error = array('code' => '404','name' => 'f_age', 'message' => 'father age is empty'); 
 array_push($Aerror, $error);
}elseif (!isset( $f_qual) || empty($f_qual)) {
	$error = array('code' => '404','name' => 'f_qual', 'message' => 'father qualification is empty');
 array_push($Aerror, $error);
}elseif (!isset( $f_prof) || empty($f_prof)) {
	$error = array('code' => '404','name' => 'f_prof', 'message' => 'father profession is empty'); 
 array_push($Aerror, $error);
}elseif (!isset( $f_phone) || empty($f_phone)) {
	$error = array('code' => '404','name' => 'f_phone', 'message' => 'father phone number is empty'); 
 array_push($Aerror, $error);
}elseif (!isset( $mname )|| empty($mname)) {
	$error = array('code' => '404','name' => 'mname', 'message' => 'mother name is empty'); 
 array_push($Aerror, $error);
}elseif (!isset( $m_age) || empty($m_age)) {
	$error = array('code' => '404','name' => 'm_age', 'message' => 'mother age is empty'); 
 array_push($Aerror, $error);
}elseif (!isset( $m_qual) || empty($m_qual)) {
	$error = array('code' => '404','name' => 'm_qual', 'message' => 'mother qualification is empty');
 array_push($Aerror, $error);
}elseif (!isset( $m_prof) || empty($m_prof)) {
	$error = array('code' => '404','name' => 'm_prof', 'message' => 'mother profession is empty'); 
 array_push($Aerror, $error);
}elseif (!isset( $m_phone) || empty($m_phone)) {
	$error = array('code' => '404','name' => 'm_phone', 'message' => 'mother phone number is empty'); 
 array_push($Aerror, $error);
}elseif (!isset( $dob) || empty($dob)) {
	$error = array('code' => '404','name' => 'dob', 'message' => 'date of birth is empty'); 
 array_push($Aerror, $error);
}elseif (!isset( $pob )|| empty($pob)) {
	$error = array('code' => '404','name' => 'pob', 'message' => 'place of birth is empty'); 
 array_push($Aerror, $error);
}
// elseif (!isset( $religion )|| empty($religion)) {
// 	$error = array('code' => '404','name' => 'religion', 'message' => 'religion is empty'); 
//  array_push($Aerror, $error);
// }elseif (!isset( $cast )|| empty($cast)) {
// 	$error = array('code' => '404','name' => 'cast', 'message' => 'cast is empty'); 
//  array_push($Aerror, $error);
// }
elseif (!isset( $address) || empty($address)) {
	$error = array('code' => '404','name' => 'address', 'message' => 'address is empty'); 
 array_push($Aerror, $error);
}elseif (!isset( $pincode )|| empty($pincode)) {
	$error = array('code' => '404','name' => 'pincode', 'message' => 'pincode is empty'); 
 array_push($Aerror, $error);
}elseif (!isset( $email )|| empty($email)) {
	$error = array('code' => '404','name' => 'email', 'message' => 'email is empty'); 
 array_push($Aerror, $error);
}elseif (!isset( $refrence )|| empty($refrence)) {
	$error = array('code' => '404','name' => 'refrence', 'message' => 'refrence is empty'); 
 array_push($Aerror, $error);
}
// elseif (!isset( $place )|| empty($place)) {
// 	$error = array('code' => '404','name' => 'place', 'message' => 'place is empty'); 
//  array_push($Aerror, $error);
// }
elseif (!isset( $branch )|| empty($branch)) {
	$error = array('code' => '404','name' => 'branch', 'message' => 'branch is empty'); 
 array_push($Aerror, $error);
}elseif (!isset( $batch )|| empty($batch)) {
	$error = array('code' => '404','name' => 'batch', 'message' => 'batch is empty'); 
 array_push($Aerror, $error);
}elseif (!isset( $btime )|| empty($btime)) {
	$error = array('code' => '404','name' => 'btime', 'message' => 'batch time is empty'); 
 array_push($Aerror, $error);
}

if (!empty($Aerror)) {
$message= array('error'=>'true','details'=>$Aerror);
// $details = json_encode($message, JSON_PRETTY_PRINT);
// echo $details;
header("Location: index.php?error=".$message['error']."&&details=".$message['details']['message']."");
exit();
}else{
	$message= array('error'=>'false','details'=>'empty');
// $details = json_encode($message, JSON_PRETTY_PRINT);
// echo $details;
$sql1="INSERT INTO `user`(`name`, `fname`,`f_age`,`f_qual`,`f_prof`,`f_phone`, `mname`,`m_age`,`m_qual`,`m_prof`,`m_phone`,`gender`, `email`, `p_address`, `pincode`, `dob`, `pob`, `refrence`,`date`,`branch`,`batch`,`btime`) VALUES ('$name','$fname','$f_age','$f_qual','$f_prof','$f_phone','$mname','$m_age','$m_qual','$m_prof','$m_phone','$gen','$email','$address',$pincode,'$dob','$pob','$refrence','$date','$branch','$batch','$btime');";

// $sql1="INSERT INTO `user`(`name`, `fname`,`f_age`,`f_qual`,`f_prof`,`f_phone`, `mname`,`m_age`,`m_qual`,`m_prof`,`m_phone`,`gender`, `email`, `p_address`, `pincode`, `dob`, `pob`, `religion`, `cast`,`refrence`,`date`,`place`,`branch`,`batch`) VALUES ('$name','$fname',`$f_age`,`$f_qual`,`$f_prof`,`$f_phone`,'$mname',`$m_age`,`$m_qual`,`$m_prof`,`$m_phone`,'$gen','$email','$address',$pincode,'$dob','$pob','$religion','$cast','$refrence','$date','$place','$branch','$batch');";
				mysqli_query($conn, $sql1) or die(mysqli_error($conn));
				$last_id = $conn->insert_id;
				$sql3="SELECT * FROM user WHERE id=".$last_id; 
                $result3=mysqli_query($conn,$sql3);
                $row3 = mysqli_fetch_assoc($result3);
                
                $message1=urlencode('Thank you! We have received your form and our team is reviewing it! will contact you asap 🤞🏻😇');
                      $url='http://text.daxy.in/http-api.php?username=kidszone&password=DU00MUD0BA&senderid=KIDZON&route=2&number='.$row3['f_phone'].'&message='.$message1.'';
                      $ch = curl_init();

                        // set URL and other appropriate options
                        curl_setopt($ch, CURLOPT_URL, $url);
                        curl_setopt($ch, CURLOPT_HEADER, 0);
                        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                        // grab URL and pass it to the browser
                        curl_exec($ch);

                        // close cURL resource, and free up system resources
                        curl_close($ch);
                
                $sql4="SELECT * FROM admin WHERE BRANCH='".$row3['branch']."'"; 
                $result4=mysqli_query($conn,$sql4);
                $row4 = mysqli_fetch_assoc($result4);
                
                $message2=urlencode(' Parent name: '.$row3['fname'].'\n Parent number: '.$row3['f_phone'].'\n has submitted \n Form no: '.date("ymd",strtotime($row3['date'])).$row3['id'].', \n have a look');
                      $url='http://text.daxy.in/http-api.php?username=kidszone&password=DU00MUD0BA&senderid=KIDZON&route=2&number='.$row4['phone'].'&message='.$message2.'';
                      $ch = curl_init();

                        // set URL and other appropriate options
                        curl_setopt($ch, CURLOPT_URL, $url);
                        curl_setopt($ch, CURLOPT_HEADER, 0);
                        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                        // grab URL and pass it to the browser
                        curl_exec($ch);

                        // close cURL resource, and free up system resources
                        curl_close($ch);
                       
                       
				
				
				header("Location: index.php?error=".$message['error']."&details=".$message['details']."");
				exit();
				
				// echo "<script>window.open('index.php?error=".message['error']."&&details=".message['details']."','_self')</script>";
                
}

 
?>
