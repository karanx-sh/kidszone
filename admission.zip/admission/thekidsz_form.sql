-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jun 15, 2020 at 05:45 PM
-- Server version: 10.2.27-MariaDB
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `thekidsz_form`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `username` varchar(256) NOT NULL,
  `password` varchar(265) NOT NULL,
  `id` int(11) NOT NULL,
  `name` varchar(256) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`username`, `password`, `id`, `name`) VALUES
('thekids', '$2y$10$P4QU240Ci1qCunfRBh7oe.zJjHaUK1kzfUlDwAjxXV8.dFCLU2LcG', 1, 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(256) NOT NULL,
  `gender` varchar(256) NOT NULL,
  `fname` varchar(256) NOT NULL,
  `f_age` varchar(256) NOT NULL,
  `f_qual` varchar(256) NOT NULL,
  `f_prof` varchar(256) NOT NULL,
  `f_phone` varchar(256) NOT NULL,
  `mname` varchar(256) NOT NULL,
  `m_age` varchar(256) NOT NULL,
  `m_qual` varchar(256) NOT NULL,
  `m_prof` varchar(256) NOT NULL,
  `m_phone` varchar(256) NOT NULL,
  `dob` varchar(256) NOT NULL,
  `pob` varchar(256) NOT NULL,
  `p_address` varchar(256) NOT NULL,
  `pincode` int(11) NOT NULL,
  `refrence` varchar(256) NOT NULL,
  `email` varchar(256) NOT NULL,
  `date` varchar(256) NOT NULL,
  `branch` varchar(256) NOT NULL,
  `batch` varchar(256) NOT NULL,
  `status` int(5) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `gender`, `fname`, `f_age`, `f_qual`, `f_prof`, `f_phone`, `mname`, `m_age`, `m_qual`, `m_prof`, `m_phone`, `dob`, `pob`, `p_address`, `pincode`, `refrence`, `email`, `date`, `branch`, `batch`, `status`) VALUES
(4, 'Cheyenne Cash', 'MALE', 'Julian Robles', '69', 'Dolore molestiae par', 'Sit blanditiis tempo', '32', 'Joan Contreras', '58', 'Nemo dolor perspicia', 'Sit placeat sunt ', '29', '2015-12-01', 'Dolorem aut consequu', 'Voluptate impedit a', 3, 'PAMPHLET', 'qegoqud@mailinator.net', '02-05-20', 'KALACHOWKY', 'JRSRKG', 1),
(5, 'Nolan Roberson', 'MALE', 'Keiko Barlow', '98', 'Illum et blanditiis', 'Porro illum officia', '97', 'Pamela Lambert', '43', 'Autem at architecto ', 'Aut quam quia pariat', '32', '2004-11-28', 'Eos dolor architect', 'Elit vel voluptatem', 43, 'BANNER', 'mapa@mailinator.com', '2020-06-15', 'WORLI', 'NURSERY', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
