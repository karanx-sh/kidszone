<?php
include_once('alert.php');
?>

<!DOCTYPE html>
<html lang="en">

<head>
	<title>Admission Form - Kidszone</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	
	 <!-- Favicon -->
    <link rel="apple-touch-icon" sizes="57x57" href="https://daxy.in/img/favicon/apple-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="https://daxy.in/img/favicon/apple-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="https://daxy.in/img/favicon/apple-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="https://daxy.in/img/favicon/apple-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="https://daxy.in/img/favicon/apple-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="https://daxy.in/img/favicon/apple-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="https://daxy.in/img/favicon/apple-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="https://daxy.in/img/favicon/apple-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="https://daxy.in/img/favicon/apple-icon-180x180.png">
    <link rel="icon" type="image/png" sizes="192x192" href="https://daxy.in/img/favicon/android-icon-192x192.png">
    <link rel="icon" type="image/png" sizes="32x32" href="https://daxy.in/img/favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="96x96" href="https://daxy.in/img/favicon/favicon-96x96.png">
    <link rel="icon" type="image/png" sizes="16x16" href="https://daxy.in/img/favicon/favicon-16x16.png">
    <link rel="manifest" href="https://daxy.in/img/favicon/manifest.json">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="https://daxy.in/img/ms-icon-144x144.png">
    <meta name="theme-color" content="#ffffff">
	<!--===============================================================================================-->
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/iconic/css/material-design-iconic-font.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/noui/nouislider.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
	<!--===============================================================================================-->
</head>

<body>

<?php
$stat=$_GET['error'];
if ($stat=='false') {
   echo "<script>swal({
      title: 'Thank You!',
      text: 'Form submitted successfully',
      type: 'success',
      padding: '2em'
    })</script>";  
}elseif ($stat=='true') {
	$stat=$_GET['details'];

    echo "<script>swal({
           title: 'Something went wrong!',
      text: '".$stat."',
      type: 'question',
      padding: '2em'
        })</script>";
}
?>
	<div class="container-contact100">
		<div class="wrap-contact100">
			<form class="contact100-form validate-form" action="register.php" method="POST">
				<span class="contact100-form-title">
					ADMISSION FORM
				</span>
				<div class="wrap-input100 bg0 ">
					<p>
						CONTACT DETAILS: <br>
						1. Kalachowki- +91 8291550999<br>
						2. Byculla- +91 8291550888<br>
						3. Sewri- +91 8291550777<br>
						4. Worli- +91 8291550666<br>
					</p>
				</div>
				<div class="wrap-input100 validate-input bg1" data-validate="PLEASR TYPE YOUR CHILD'S NAME">
					<span class=" label-input100">CHILD'S NAME *</span>
					<input class="input100" type="text" name="name" placeholder="Alisha Kamal Parab" required
						style="text-transform: uppercase;">
				</div>

				<div class="wrap-input100 input100-select bg1 rs1-wrap-input100"
					data-validate="PLEASE SELECT YOUR CHILD'S GENDER">
					<span class="label-input100">CHILD'S GENDER *</span>
					<div>
						<select class="js-select2" name="gen" required>

							<option>FEMALE</option>
							<option>MALE</option>
						</select>
						<div class="dropDownSelect2"></div>
					</div>
				</div>

				<div class="wrap-input100 validate-input bg1 rs1-wrap-input100"
					data-validate="PLEASE SELECT YOUR CHILD'S BIRTHDATE">
					<span class="label-input100">CHILD'S BIRTH DATE *</span>
					<input class="input100" type="date" name="dob" required style="text-transform: uppercase;">
				</div>

				<div class="wrap-input100 validate-input bg1 rs1-wrap-input100"
					data-validate="PLEASE TYPE YOUR CHILD'S BIRTHPLACE">
					<span class="label-input100">CHILD'S BIRTH PLACE *</span>
					<input class="input100" type="text" name="pob" placeholder="" required
						style="text-transform: uppercase;">
				</div>

				<div class="wrap-input100 validate-input bg1 rs1-alert-validate"
					data-validate="PLEASE TYPE YOUR PERMANENT ADDRESS">
					<span class="label-input100">PERMANENT ADDRESS *</span>
					<textarea class="input100" name="address" placeholder="" required
						style="text-transform: uppercase;"></textarea>
				</div>

				<div class="wrap-input100 validate-input bg1 rs1-wrap-input100"
					data-validate="ENTER YOUR PINCODE OF YOUR RESPECTIVE AREA">
					<span class="label-input100">PINCODE *</span>
					<input class="input100" type="number" name="pincode" placeholder="" required
						style="text-transform: uppercase;">
				</div>

				<div class="wrap-input100 validate-input bg1" data-validate="PLEASE TYPE MOTHER'S NAME">
					<span class="label-input100">MOTHER's NAME *</span>
					<input class="input100" type="text" name="mname" placeholder="" required>
				</div>

				<div class="wrap-input100 validate-input bg1 rs1-wrap-input100"
					data-validate="PLEASE TYPE MOTHER'S AGE">
					<span class="label-input100">MOTHER's AGE *</span>
					<input class="input100" type="number" minlength="2" maxlength="2" name="m_age" placeholder=""
						required>
				</div>

				<div class="wrap-input100 validate-input bg1 rs1-wrap-input100"
					data-validate="PLEASE TYPE MOTHER'S QUALIFICATION">
					<span class="label-input100">MOTHER's QUALIFICATION *</span>
					<input class="input100" type="text" name="m_qual" placeholder="" required>
				</div>

				<div class="wrap-input100 validate-input bg1 rs1-wrap-input100"
					data-validate="PLEASE TYPE MOTHER'S PROFESSION">
					<span class="label-input100">MOTHER's PROFESSION *</span>
					<input class="input100" type="text" name="m_prof" placeholder="" required>
				</div>

				<div class="wrap-input100 validate-input bg1 rs1-wrap-input100"
					data-validate="PLEASE TYPE MOTHER'S PHONE">
					<span class="label-input100">MOTHER's PHONE *</span>
					<input class="input100" type="number" minlength="10" maxlength="10" name="m_phone" placeholder=""
						required>
				</div>

				<div class="wrap-input100 validate-input bg1" data-validate="PLEASE TYPE FATHER'S NAME">
					<span class="label-input100">FATHER's NAME *</span>
					<input class="input100" type="text" name="fname" placeholder="" required>
				</div>

				<div class="wrap-input100 validate-input bg1 rs1-wrap-input100"
					data-validate="PLEASE TYPE FATHER'S AGE">
					<span class="label-input100">FATHER's AGE *</span>
					<input class="input100" type="number" minlength="2" maxlength="2" name="f_age" placeholder=""
						required>
				</div>

				<div class="wrap-input100 validate-input bg1 rs1-wrap-input100"
					data-validate="PLEASE TYPE FATHER'S QUALIFICATION">
					<span class="label-input100">FATHER's QUALIFICATION *</span>
					<input class="input100" type="text" name="f_qual" placeholder="" required>
				</div>

				<div class="wrap-input100 validate-input bg1 rs1-wrap-input100"
					data-validate="PLEASE TYPE FATHER'S PROFESSION">
					<span class="label-input100">FATHER's PROFESSION *</span>
					<input class="input100" type="text" name="f_prof" placeholder="" required>
				</div>


				<div class="wrap-input100 validate-input bg1 rs1-wrap-input100"
					data-validate="PLEASE TYPE FATHER'S PHONE">
					<span class="label-input100">FATHER's PHONE *</span>
					<input class="input100" type="number" name="f_phone" minlength="10" maxlength="10" placeholder=""
						required>
				</div>


				<div class="" style="width: 100%;">
					<div class="wrap-input100 validate-input bg1 rs1-wrap-input100"
						data-validate="Enter Your Email address">
						<span class="label-input100">Email *</span>
						<input class="input100" type="text" name="email" placeholder="" required>
					</div>
				</div>

				<br>

				<div class="wrap-input100 input100-select bg1">
					<p>
						<span class="label-input100">BRANCH *</span>
						<div>
							<select id="branch" class="js-select2" name="branch" required>

								<option>BYCULLA</option>
								<option>KALACHOWKY</option>
								<option>SEWREE</option>
								<option>WORLI</option>
							</select>
							<div class="dropDownSelect2"></div>
							<a href="https://thekidszone.in/contact-us"
								style="font-family: Montserrat-SemiBold; text-transform: uppercase; text-decoration: underline;"
								target="_blank ">ADDRESS
								AND
								Details</a>
					</p>
				</div>
		</div>



		<div class="wrap-input100 input100-select bg1 rs1-wrap-input100">
			<span class="label-input100">BATCH *</span>
			<div>
				<select id="batch" class="js-select2" name="batch" required>

					<option>PLAYGROUP</option>
					<option>NURSERY</option>
					<option>JRSRKG</option>
				</select>
				<div class="dropDownSelect2"></div>
			</div>
		</div>


		<div class="wrap-input100 input100-select bg1 rs1-wrap-input100">
			<span class="label-input100">BATCH TIMING*</span>
			<div>
				<select id="timing" class="js-select2" name="btime" required>
				</select>
				<div class="dropDownSelect2"></div>
			</div>
		</div>




		<div style="margin-top: 40px;" class="wrap-input100 input100-select bg1 rs1-wrap-input100">
			<span class="label-input100">How did you find us?</span>
			<div>
				<select class="js-select2" name="reference" style="text-transform: uppercase;">

					<option>WEBSITE</option>
					<option>BANNER</option>
					<option>PAMPHLET</option>
					<option>FACEBOOK, OTHER SOCIAL MEDIA</option>
					<option>FRIENDS AND RELATIVES</option>


				</select>
				<div class="dropDownSelect2"></div>
			</div>
		</div>


		<div class="wrap-input100 bg0 ">
			<p>
				By submitting the form, I certify that I have read, understand, and adhere to all
				applicable guidelines and agreements and the information that i have given is True.

			</p>
		</div>



		<div class="container-contact100-form-btn">
			<button class="contact100-form-btn">
				<span>
					Submit
					<i class="fa fa-long-arrow-right m-l-7" aria-hidden="true"></i>
				</span>
			</button>
		</div>
		</form>

		<div>

		</div>
		<div class="wrap-input100 bg0 " style="margin-top: 40px;;">
			<p>
				NOTE: <br>
				1. ONCE THE FORM IS SUBMITTED, WE'LL SEND YOU A CONFIRMATION MESSAGE.<br>
				2. FOR PAYMENT DETAILS CONTACT THE PERSONNEL ASSIGNED.<br>
				3. ASSIGNED PERSONNELS CONTACT NUMBER WILL BE SENT TO YOU BY TEXT.<br>
				4. FORM WILL BE CONFIRMED AFTER SUCCESSFULL PAYMENT ONLY.<br>
				5. Documents to be submitted before joining! 4 photograph, Birth Certificate, Address Proof, Aadhar card
				of
				both parents
			</p>
		</div>
		<p style="text-align: center; margin-top: 50px;">Handcrafted with ❤️ by <a href="https://daxy.in"
				style="font-family: Montserrat-SemiBold; text-transform: uppercase; text-decoration: underline;">Team
				Daxy</a>.</p>
	</div>

	</div>

	<footer>

	</footer>

	<!--===============================================================================================-->
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
	<!--===============================================================================================-->
	<script src="vendor/animsition/js/animsition.min.js"></script>
	<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
	<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
	<script>
		$(".js-select2").each(function () {
			$(this).select2({
				minimumResultsForSearch: 20,
				dropdownParent: $(this).next('.dropDownSelect2')
			});


			$(".js-select2").each(function () {
				$(this).on('select2:close', function (e) {
					if ($(this).val() == "Please chooses") {
						$('.js-show-service').slideUp();
					}
					else {
						$('.js-show-service').slideUp();
						$('.js-show-service').slideDown();
					}
				});
			});
		})
	</script>
	<!--===============================================================================================-->
	<script src="vendor/daterangepicker/moment.min.js"></script>
	<script src="vendor/daterangepicker/daterangepicker.js"></script>
	<!--===============================================================================================-->
	<script src="vendor/countdowntime/countdowntime.js"></script>
	<!--===============================================================================================-->
	<script src="vendor/noui/nouislider.min.js"></script>
	<!--===============================================================================================-->
	<script src="js/main.js"></script>
	<script>

		let branchv = '',
			batchv = '';
		let timings = {
			WORLI: {
				PLAYGROUP: '11:30 AM to 1:30 PM',
				NURSERY: ['09:00 AM to 11:00 AM', '11:30 AM TO 02:00 PM'],
				JRSRKG: '08:30 AM TO 11:00 AM'
			}
			,
			KALACHOWKY: {
				PLAYGROUP: '09:00 AM to 11:00 AM',
				NURSERY: '11:30 AM to 02:00 PM',
				JRSRKG: '02:30 PM TO 04:30 PM'
			},

			SEWREE: {
				PLAYGROUP: '09:00 AM to 11:00 AM',
				NURSERY: '11:30 AM to 02:00 PM',
				JRSRKG: '08:30 AM TO 11:00 AM'
			},

			BYCULLA: {
				PLAYGROUP: '09:00 AM to 11:00 AM',
				NURSERY: ['08:30 AM to 11:00 AM', '11:30 AM TO 02:00 PM'],
				JRSRKG: '02:30 PM TO 05:00 PM'

			}
		}
		let timingContainer = document.querySelector('#timing');

		$('#branch').change(() => {
			batchv = $('#batch').val();
			branchv = $('#branch').val();
			addOptions(timings[branchv][batchv]);
		});

		$('#batch').change(() => {

			batchv = $('#batch').val();
			branchv = $('#branch').val();
			addOptions(timings[branchv][batchv]);

		});

		let addOptions = (arr) => {
			timingContainer.innerHTML = '';
			if (Array.isArray(arr)) {
				arr.forEach(e => {
					timingContainer.insertAdjacentHTML("beforeend", `<option>${e}</option>`);
				});
			} else {
				timingContainer.insertAdjacentHTML("beforeend", `<option>${arr}</option>`);
			}

		}
	</script>

</body>

</html>