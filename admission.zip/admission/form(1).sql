-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: May 02, 2020 at 04:54 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `form`
--

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(256) NOT NULL,
  `gender` varchar(256) NOT NULL,
  `fname` varchar(256) NOT NULL,
  `f_age` varchar(256) NOT NULL,
  `f_qual` varchar(256) NOT NULL,
  `f_prof` varchar(256) NOT NULL,
  `f_phone` varchar(256) NOT NULL,
  `mname` varchar(256) NOT NULL,
  `m_age` varchar(256) NOT NULL,
  `m_qual` varchar(256) NOT NULL,
  `m_prof` varchar(256) NOT NULL,
  `m_phone` varchar(256) NOT NULL,
  `dob` varchar(256) NOT NULL,
  `pob` varchar(256) NOT NULL,
  `p_address` varchar(256) NOT NULL,
  `pincode` int(11) NOT NULL,
  `refrence` varchar(256) NOT NULL,
  `email` varchar(256) NOT NULL,
  `date` varchar(256) NOT NULL,
  `branch` varchar(256) NOT NULL,
  `batch` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
